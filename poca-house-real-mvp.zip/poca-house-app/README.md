# 포카하우스 MVP

알바해서 코인 벌고, 포카팩을 뽑고, 방 벽에 포카를 붙이는 PWA MVP입니다.

## 로컬 실행
```bash
npm install
npm run dev
```

## Vercel 배포
1. GitHub에 이 폴더 업로드
2. Vercel > New Project > GitHub repo 선택
3. Environment Variables 추가
   - VITE_SUPABASE_URL
   - VITE_SUPABASE_ANON_KEY
4. Deploy

## Supabase 연결
- Supabase 프로젝트 생성
- Authentication > Providers > Email 활성화
- SQL Editor에서 `supabase.sql` 실행

현재 앱은 Supabase 환경변수가 없으면 로컬 저장 모드로도 작동합니다.
