import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createClient } from '@supabase/supabase-js';
import { Coffee, Sparkles, Home, ImagePlus, Save, Share2, LogOut } from 'lucide-react';
import './style.css';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = SUPABASE_URL && SUPABASE_ANON_KEY ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

const STARTER_CARDS = [
  { title: '벚꽃 포카', bg: 'linear-gradient(135deg,#ffd1e8,#fff5fb)', icon: '🌸' },
  { title: '별빛 포카', bg: 'linear-gradient(135deg,#d8dcff,#fff)', icon: '✨' },
  { title: '고양이 포카', bg: 'linear-gradient(135deg,#ffe2b8,#fff5e8)', icon: '🐱' },
  { title: '카페 포카', bg: 'linear-gradient(135deg,#d7b18d,#fff1df)', icon: '☕' },
  { title: '천사 포카', bg: 'linear-gradient(135deg,#f7f7ff,#d9f4ff)', icon: '🪽' },
  { title: '우주 포카', bg: 'linear-gradient(135deg,#272044,#8c78ff)', icon: '🌙' },
  { title: '리본 포카', bg: 'linear-gradient(135deg,#ffc4df,#ffeef7)', icon: '🎀' },
  { title: '행운 포카', bg: 'linear-gradient(135deg,#fff0a8,#fff8db)', icon: '🍀' }
];

function uid(){ return Math.random().toString(36).slice(2) + Date.now().toString(36); }
const localKey = 'poca-house-demo-v2';

const defaultState = {
  coins: 100,
  cards: [],
  placed: [],
  lastWorkAt: 0,
  roomTheme: 'pink'
};

function loadLocal(){
  try { return { ...defaultState, ...JSON.parse(localStorage.getItem(localKey) || '{}') }; }
  catch { return defaultState; }
}

function Auth({ onSession }){
  const [email,setEmail]=useState('');
  const [sent,setSent]=useState(false);
  const [error,setError]=useState('');
  async function login(){
    setError('');
    if(!supabase){ setError('Supabase 환경변수가 아직 연결되지 않았어. 지금은 로컬 저장 모드로 실행돼.'); return; }
    const { error } = await supabase.auth.signInWithOtp({ email, options:{ emailRedirectTo: window.location.origin }});
    if(error) setError(error.message); else setSent(true);
  }
  return <div className="auth-card">
    <h1>포카하우스</h1>
    <p>알바해서 코인 벌고, 포카 뽑아서 내 방 벽에 붙이는 덕질방.</p>
    <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="이메일 입력" />
    <button onClick={login}>이메일로 로그인 링크 받기</button>
    <button className="ghost" onClick={()=>onSession({ user:{ id:'local-demo', email:'demo@local' }})}>로그인 없이 체험하기</button>
    {sent && <small>메일함에서 로그인 링크를 눌러줘.</small>}
    {error && <small className="error">{error}</small>}
  </div>
}

function PocaCard({ card, tiny=false }){
  return <div className={tiny?'poca-card tiny':'poca-card'} style={{background:card.bg}}>
    <div className="poca-icon">{card.icon}</div>
    <div className="poca-title">{card.title}</div>
  </div>
}

function App(){
  const [session,setSession]=useState(null);
  const [state,setState]=useState(loadLocal);
  const [selected,setSelected]=useState(null);
  const [drag,setDrag]=useState(null);
  const roomRef=useRef(null);

  useEffect(()=>{
    if(!supabase) return;
    supabase.auth.getSession().then(({data})=>setSession(data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session)=>setSession(session));
    return ()=>sub.subscription.unsubscribe();
  },[]);

  useEffect(()=>{ localStorage.setItem(localKey, JSON.stringify(state)); },[state]);

  const canWork = Date.now() - state.lastWorkAt > 10000;
  const ownedCount = state.cards.length;

  function doWork(){
    if(!canWork) return;
    setState(s=>({...s, coins:s.coins+50, lastWorkAt:Date.now()}));
  }

  function buyPack(){
    if(state.coins < 100) return alert('코인이 부족해. 카페 알바를 해줘!');
    const base = STARTER_CARDS[Math.floor(Math.random()*STARTER_CARDS.length)];
    const card = { ...base, id:uid() };
    setState(s=>({...s, coins:s.coins-100, cards:[card,...s.cards]}));
    setSelected(card);
  }

  function placeCard(card){
    setState(s=>({...s, placed:[...s.placed,{...card, placeId:uid(), x:20+Math.random()*45, y:10+Math.random()*35}]}));
  }

  function pointerDown(e,item){
    const rect=roomRef.current.getBoundingClientRect();
    setDrag({id:item.placeId, dx:e.clientX-rect.left-(item.x/100*rect.width), dy:e.clientY-rect.top-(item.y/100*rect.height)});
  }
  function pointerMove(e){
    if(!drag) return;
    const rect=roomRef.current.getBoundingClientRect();
    const x=Math.max(0,Math.min(82,((e.clientX-rect.left-drag.dx)/rect.width)*100));
    const y=Math.max(0,Math.min(76,((e.clientY-rect.top-drag.dy)/rect.height)*100));
    setState(s=>({...s, placed:s.placed.map(p=>p.placeId===drag.id?{...p,x,y}:p)}));
  }

  async function shareRoom(){
    const text = `내 포카하우스: 포카 ${ownedCount}장, 전시 ${state.placed.length}장!`;
    if(navigator.share){ try{ await navigator.share({title:'포카하우스', text, url:location.href}); }catch{} }
    else { await navigator.clipboard.writeText(text); alert('공유 문구를 복사했어!'); }
  }

  if(!session) return <main className="center"><Auth onSession={setSession}/></main>;

  return <div className="app">
    <header>
      <div><b>포카하우스</b><span>내 취향으로 채우는 작은 방</span></div>
      <button className="ghost small" onClick={async()=> supabase ? await supabase.auth.signOut() : setSession(null)}><LogOut size={16}/>나가기</button>
    </header>

    <section className="status">
      <div><strong>{state.coins}</strong><span>코인</span></div>
      <div><strong>{ownedCount}</strong><span>보유 포카</span></div>
      <div><strong>{state.placed.length}</strong><span>전시 중</span></div>
    </section>

    <section className="actions">
      <button onClick={doWork} disabled={!canWork}><Coffee/> 카페 알바 +50</button>
      <button onClick={buyPack}><Sparkles/> 포카팩 100코인</button>
      <button onClick={shareRoom}><Share2/> 방 자랑</button>
    </section>
    {!canWork && <p className="hint">알바는 10초마다 가능해. MVP 테스트용 짧은 쿨타임이야.</p>}

    <section className="room-wrap">
      <h2><Home size={18}/> 내 방</h2>
      <div ref={roomRef} className={`room ${state.roomTheme}`} onPointerMove={pointerMove} onPointerUp={()=>setDrag(null)} onPointerCancel={()=>setDrag(null)}>
        <div className="wall-grid"></div>
        <div className="sofa">🛋️</div>
        <div className="plant">🪴</div>
        {state.placed.map(item=><div key={item.placeId} className="placed" style={{left:item.x+'%',top:item.y+'%'}} onPointerDown={e=>pointerDown(e,item)}><PocaCard card={item} tiny/></div>)}
      </div>
    </section>

    <section className="inventory">
      <h2><ImagePlus size={18}/> 내 포카</h2>
      {state.cards.length===0 ? <p className="empty">아직 포카가 없어. 알바하고 포카팩을 뽑아봐.</p> : <div className="cards">{state.cards.map(card=><button key={card.id} className="card-btn" onClick={()=>placeCard(card)}><PocaCard card={card}/><small>방에 붙이기</small></button>)}</div>}
    </section>
  </div>
}

createRoot(document.getElementById('root')).render(<App/>);
