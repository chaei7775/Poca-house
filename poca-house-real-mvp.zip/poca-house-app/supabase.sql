-- Supabase SQL Editor에서 실행할 기본 테이블 초안
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  coins integer default 100,
  created_at timestamptz default now()
);

create table if not exists cards (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  title text not null,
  icon text,
  bg text,
  created_at timestamptz default now()
);

create table if not exists placed_cards (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  card_id uuid references cards(id) on delete cascade,
  x numeric default 20,
  y numeric default 20,
  created_at timestamptz default now()
);

alter table profiles enable row level security;
alter table cards enable row level security;
alter table placed_cards enable row level security;

create policy "profiles own select" on profiles for select using (auth.uid() = id);
create policy "profiles own update" on profiles for update using (auth.uid() = id);
create policy "profiles own insert" on profiles for insert with check (auth.uid() = id);

create policy "cards own all" on cards for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "placed own all" on placed_cards for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
